
console.log("Modern Blue Gaming UI loaded");

document.addEventListener("DOMContentLoaded", ()=>{
    console.log("UI fully active.");
});
